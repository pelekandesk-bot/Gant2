package ir.pelekanoffice.projectcontrol

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val notificationChannelId = "pelekan_project_reminders"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.rgb(241, 246, 249)
        window.navigationBarColor = Color.rgb(241, 246, 249)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        createNotificationChannel()

        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(241, 246, 249))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.mediaPlaybackRequiresUserGesture = true
            settings.textZoom = 100
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                settings.safeBrowsingEnabled = true
            }

            addJavascriptInterface(AndroidBridge(this@MainActivity), "PelekanAndroid")

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val uri = request?.url ?: return false
                    val isBundledAsset =
                        uri.scheme == "file" && uri.path?.startsWith("/android_asset/") == true
                    return !isBundledAsset && uri.toString() != "about:blank"
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: android.webkit.WebResourceError?
                ) {
                    if (request?.isForMainFrame == true) {
                        runOnUiThread {
                            Toast.makeText(
                                this@MainActivity,
                                "بارگذاری برنامه با مشکل روبه‌رو شد.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                }
            }
            webChromeClient = WebChromeClient()
        }

        setContentView(webView)
        webView.loadUrl("file:///android_asset/pelekan.html")
    }

    private inner class AndroidBridge(private val activity: Activity) {
        @JavascriptInterface
        fun saveBase64File(base64: String, requestedName: String, requestedMime: String) {
            try {
                require(base64.length <= 30_000_000) { "FILE_TOO_LARGE" }
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                val safeName = requestedName
                    .replace(Regex("[\\\\/:*?\"<>|]"), "_")
                    .take(140)
                    .ifBlank { "pelekan-export.dat" }
                val mime = requestedMime.substringBefore(";").ifBlank {
                    "application/octet-stream"
                }

                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
                    put(MediaStore.MediaColumns.MIME_TYPE, mime)
                    put(
                        MediaStore.MediaColumns.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/Pelekan"
                    )
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }

                val resolver = activity.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Cannot create download")

                resolver.openOutputStream(uri)?.use { stream ->
                    stream.write(bytes)
                    stream.flush()
                } ?: throw IllegalStateException("Cannot open download stream")

                val completed = ContentValues().apply {
                    put(MediaStore.MediaColumns.IS_PENDING, 0)
                }
                resolver.update(uri, completed, null, null)

                activity.runOnUiThread {
                    Toast.makeText(
                        activity,
                        "فایل در پوشه Downloads/Pelekan ذخیره شد.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (error: Exception) {
                activity.runOnUiThread {
                    Toast.makeText(
                        activity,
                        "ذخیره فایل ناموفق بود: ${error.message ?: "خطا"}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }

        @JavascriptInterface
        fun requestNotificationPermission() {
            activity.runOnUiThread {
                if (Build.VERSION.SDK_INT >= 33 &&
                    activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED
                ) {
                    activity.requestPermissions(
                        arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                        3201
                    )
                } else {
                    Toast.makeText(
                        activity,
                        "اجازه اعلان‌ها فعال است.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        @JavascriptInterface
        fun showNotification(id: String, title: String, body: String): Boolean {
            if (Build.VERSION.SDK_INT >= 33 &&
                activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                return false
            }

            return try {
                val launchIntent = Intent(activity, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                }
                val pendingIntent = PendingIntent.getActivity(
                    activity,
                    id.hashCode(),
                    launchIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                val notification = Notification.Builder(activity, notificationChannelId)
                    .setSmallIcon(R.drawable.ic_notification)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setAutoCancel(true)
                    .setContentIntent(pendingIntent)
                    .build()

                val manager =
                    activity.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                manager.notify(id.hashCode(), notification)
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                notificationChannelId,
                "یادآورهای پروژه پلکان",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "یادآوری موعد فعالیت‌های پروژه"
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onBackPressed() {
        if (!::webView.isInitialized) {
            finish()
            return
        }
        webView.evaluateJavascript(
            "(function(){return window.PelekanAndroidHandleBack ? window.PelekanAndroidHandleBack() : false;})()"
        ) { result ->
            if (result != "true") finish()
        }
    }

    override fun onPause() {
        if (::webView.isInitialized) webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) webView.onResume()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("PelekanAndroid")
            webView.stopLoading()
            webView.loadUrl("about:blank")
            webView.destroy()
        }
        super.onDestroy()
    }
}
