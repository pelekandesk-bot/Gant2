plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ir.pelekanoffice.projectcontrol"
    compileSdk = 35

    defaultConfig {
        applicationId = "ir.pelekanoffice.projectcontrol"
        minSdk = 29
        targetSdk = 34
        versionCode = 32
        versionName = "32.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildTypes {
        debug {
            // Debug signing is used for the first sideloadable build.
            // Configure a stable private release keystore before publishing upgrades.
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}
