# PELEKAN OFFICE — Project Control Android

نسخه پایه: HTML نسخه ۳۲  
شناسه برنامه: `ir.pelekanoffice.projectcontrol`  
نسخه اندروید: `32.0`  
حداقل Android: 10 (API 29)  
Target SDK: 35

## امکانات بسته

- فایل HTML نسخه ۳۲ در `app/src/main/assets/pelekan.html`
- پوسته Native Android با WebView تمام‌صفحه
- نگهداری داده‌های محلی WebView / localStorage بین اجراها
- آیکون اختصاصی پلکان
- دکمه Back اندروید برای خروج از حالت ویرایش، بازگشت به فهرست پروژه‌ها و سپس خروج
- خروجی JSON و ICS در پوشه `Downloads/Pelekan`
- کانال اعلان اندروید برای یادآورهای موعد فعالیت‌ها؛ برای فعال‌سازی، کاربر باید اجازه اعلان را یک‌بار تأیید کند

## ساخت APK از طریق GitHub Actions

Workflow آماده در مسیر `.github/workflows/build-apk.yml` قرار دارد.

پس از قرار گرفتن پروژه در یک Repository گیت‌هاب:
1. شاخه `main` را Push کنید یا از Actions گزینه `Build Pelekan Android APK` را با `Run workflow` اجرا کنید.
2. پس از موفقیت، Artifact با نام `pelekan-office-project-control-v32-apk` ساخته می‌شود.
3. فایل APK داخل Artifact قرار دارد. این APK با کلید Debug استاندارد اندروید امضا می‌شود و برای نصب مستقیم روی گوشی مناسب است.

## ساخت محلی با Android Studio

نیاز است:
- JDK 17
- Android SDK Platform 35
- Android Build Tools 35.0.0
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin Gradle Plugin 2.0.21

Task ساخت: `assembleDebug`  
خروجی: `app/build/outputs/apk/debug/app-debug.apk`

## نکات نصب و امنیت

- برای نصب APK دانلودشده از بیرون Play Store، Android ممکن است اجازه «Install unknown apps» را برای مرورگر یا فایل‌منیجر درخواست کند. این مجوز امنیتی سیستم‌عامل است و نمی‌توان آن را از داخل APK حذف کرد.
- این نسخه داده‌ها را محلی روی همان دستگاه نگه می‌دارد؛ هنوز به Supabase یا ذخیره‌سازی ابری وصل نشده است.
- کلید امضای انتشار Play Store در این بسته وجود ندارد. APK خروجی Workflow یک Debug-signed APK برای نصب مستقیم و آزمایش است.
- هیچ کلید محرمانه‌ای در برنامه قرار داده نشده است.

## یادآوری‌ها

اعلان‌ها در زمان اجرای برنامه و بررسی زمان‌بندی داخلی فعال می‌شوند. برای یادآوری پایدار حتی وقتی برنامه بسته است، باید در نسخه بعدی زمان‌بند بومی اندروید (WorkManager/AlarmManager) تکمیل شود. خروجی ICS فعلی نیز برای وارد کردن موعدها به تقویم گوشی باقی مانده است.

## به‌روزرسانی نسخه‌های بعدی

برای اینکه نسخه‌های بعدی بدون حذف برنامه روی نسخه نصب‌شده به‌روزرسانی شوند، باید یک کلید امضای ثابت و خصوصی برای انتشار تعریف شود و به‌صورت GitHub Actions Secret نگهداری شود. کلید Debug برای build اولیه است و نباید مبنای انتشار عمومی یا نگهداری بلندمدت داده‌ها باشد.
